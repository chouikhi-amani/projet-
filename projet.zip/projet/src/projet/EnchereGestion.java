package projet;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;



public class EnchereGestion extends Thread {
	
	 private Socket s ;
	 public EnchereGestion(membre m) {
		super();
		
	}
	public EnchereGestion(Socket s )
	 {
		 this.s=s; 
		 
	 }
 public void run () {
	 try {
		 BufferedReader in_sc=new BufferedReader(new InputStreamReader(s.getInputStream()));
		 PrintWriter out_sc=new PrintWriter(s.getOutputStream(),true); 
		  while (true)
		  {
			  String msg=in_sc.readLine(); 
			  if (msg.startsWith("ENCHERES")){
				  for (Encheres ench:Serveur.listench) {
					  if (Encheres.getEtat()==1) {
					  msg+=ench.getId()+"#"+ench.getEtat()+"#"+ench.getdesc()+"#"+ench.getPrixdepart();
				  }   
				  } out_sc.println(msg);
			  }
			  if (msg.startsWith("JOIN")) {
				  String cd=msg.substring(5);
				  String tab[]=cd.split(""); 
			  for (membre ench:Encheres.getListmemb()) {
				  if (Encheres.getId()==Integer.parseInt(tab[1])){
					  membre m1=new membre(); 
					  Serveur.listmemb.add(m1); 
					  
				  }
				  
			  }
				  
			  System.out.println("membre ajoute avec succres");
			 
				  
			  }
			  if (msg.startsWith("OFFRE")) {
				  String cd = msg.substring(6); 
				  String tab []=cd.split("##"); 
				  Encheres e=null; 
				  offre offre = null; 
				  String s =""; 
				  for (offre off:Serveur.listoffre)
				  if ((Encheres.idproduit==Integer.parseInt(tab[0]) && ((Integer.parseInt(tab[1]) > offre.getPrix())) )){
					  Encheres Encheres = e; 
					  
					  Serveur.listoffre.add(offre); 
					  s+="une offre est ajoutee" ; 
				  }else 
					  s+="offre non valide "; 
					  
				  }
				  
			if(msg.startsWith("LIST")) {
				String s =""; 
				String cd= msg.substring(5);
				String tab [] = cd.split(""); 
				if (Encheres.getId()==Integer.parseInt(tab[0])) {
					for (offre off:Serveur.listoffre) {
						s+=off.getMembre()+"+"+off.getEnchere()+"+"+off.getPrix(); 
								
					}
				}	System.out.println(s);
			}	
			}	
	} catch (Exception e) {
		// TODO: handle exception
	
		 
	 }
 }
private String getPrix() {
	// TODO Auto-generated method stub
	return null;
}
private String getdesc() {
	// TODO Auto-generated method stub
	return null;
}
}
