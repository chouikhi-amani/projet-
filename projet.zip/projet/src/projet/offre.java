package projet;

public class offre {
	private membre membre; 
	private Encheres enchere ; 
	private  static  float prix ;
	
	public offre(projet.membre membre, Encheres enchere, float prix) {
		super();
		this.membre = membre;
		this.enchere = enchere;
		this.prix = prix;
	} 
	
	
	
	public membre getMembre() {
		return membre;
	}


	public void setMembre(membre membre) {
		this.membre = membre;
	}


	public Encheres getEnchere() {
		return enchere;
	}


	public void setEnchere(Encheres enchere) {
		this.enchere = enchere;
	}


	public static float getPrix() {
		return prix;
	}


	public void setPrix(float prix) {
		this.prix = prix;
	}


	

}
