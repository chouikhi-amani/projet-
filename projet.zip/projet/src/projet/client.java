package projet;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class client {
	public static void main (String args []) {
	try {
		Socket clientSocket =new Socket ("127.0.0.1",4000) ; 
		BufferedReader inFromuSER= new BufferedReader(new InputStreamReader(System.in)); 
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 
		PrintWriter OutToServer =  new PrintWriter( new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
		
		String msgmodifier=""; 
		while(true) {
			String msg=inFromuSER.readLine();
			OutToServer.println(msg);
			msgmodifier=inFromServer.readLine(); 
			System.out.println("from server"+msgmodifier );

		}
				
	} catch (Exception e ) {
		
	}
	
	}
}


	




