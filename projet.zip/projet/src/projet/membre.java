package projet;

public class membre {
	private int id; 
	private String name;
	static private  int nb = 0;
	
	
	public membre(int id, String name) {
		super();
		this.id = nb++;
		this.name = name;
	}
	
	public membre() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static int getNb() {
		return nb;
	}

	public static void setNb(int nb) {
		membre.nb = nb;
	}

	
		 
	
	
}

	




