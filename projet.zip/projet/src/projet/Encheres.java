package projet;

import java.util.ArrayList;

import java.util.List;



public class Encheres {
	static int id;
	static String desc ;
	static int idproduit; 
	static float prixdepart ; 
	static int  heurefin; 
	static int etat;
	private static int nb=0; 
	private static List< membre> listmemb ; 
	
	public Encheres(int id, String desc, float prix, int heurefin, int etat) {
		super();
		this.id = nb++;
		this.desc = desc;
		this.prixdepart = prix;
		this.heurefin = heurefin;
		this.etat = etat;
		
	
	
	}
	

	
	
	public static int getIdproduit() {
		return idproduit;
	}




	public static void setIdproduit(int idproduit) {
		Encheres.idproduit = idproduit;
	}




	public Encheres(List<membre> listmemb) {
		super();
		this.setListmemb(listmemb);
	}

	


	
	

	public void setEtat(int etat) {
		this.etat = etat;
	}

	public static int getEtat() {
		// TODO Auto-generated method stub
		return etat;
	}

	public static String getdesc() {
		// TODO Auto-generated method stub
		return desc;
	}

	public static int getId() {
		return id;
	}

	public static void setId(int id) {
		Encheres.id = id;
	}

	public static float getPrixdepart () {
		return prixdepart;
	}

	public static void setPrixdepart (float prixdepart) {
		Encheres.prixdepart = prixdepart;
	}

	public static int getHeurefin() {
		return heurefin;
	}

	public static void setHeurefin(int heurefin) {
		Encheres.heurefin = heurefin;
	}

	public static int getNb() {
		return nb;
	}

	public static void setNb(int nb) {
		Encheres.nb = nb;
	}

	public static void setDesc(String desc) {
		Encheres.desc = desc;
	}

	public static List< membre> getListmemb() {
		return listmemb;
	}

	public void setListmemb(List< membre> listmemb) {
		this.listmemb = listmemb;
	} 
	
	
		
	

}
